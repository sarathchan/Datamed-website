// Export all animation components for easy importing
export { default as FadeIn } from './FadeIn';
export { default as StaggeredContainer } from './StaggeredContainer';
export { default as HoverScale } from './HoverScale';
export { default as ParallaxScroll } from './ParallaxScroll';
